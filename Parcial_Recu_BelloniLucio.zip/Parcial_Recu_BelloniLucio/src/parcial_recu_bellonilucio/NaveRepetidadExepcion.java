
package parcial_recu_bellonilucio;


public class NaveRepetidadExepcion  extends RuntimeException {
    
    private static  final String MESSAGE = "La nava ya esta en la lista";
    
    public NaveRepetidadExepcion()
    {
        super(MESSAGE);
    }
    
}
