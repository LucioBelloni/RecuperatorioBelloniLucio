
package parcial_recu_bellonilucio;

import java.util.Objects;


public class Nave {
    private String nombre;
    private int capacidad;
    private int anioDeLanzamiento;

    public Nave(String nombre, int capacidad, int anioDeLanzamiento) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.anioDeLanzamiento = anioDeLanzamiento;
    }

    @Override
    public String toString() {
        return " nombre: " + nombre + " capacidad: " + capacidad + " anioDeLanzamiento: " + anioDeLanzamiento;
    }
    
     @Override
    public boolean equals(Object obj) 
    {
        if (obj == null || getClass() != obj.getClass() ) {
            return false;
        }
        
        if (this == obj) 
        {
            return true;
        }
        
        if(obj instanceof Nave other)
        {
            return nombre.equals(other.nombre) && (anioDeLanzamiento == other.anioDeLanzamiento);        
        }
        
        return  false; 
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + Objects.hashCode(this.nombre);
        hash = 89 * hash + this.anioDeLanzamiento;
        return hash;
    }
    
    
    
    
    
}
