
package parcial_recu_bellonilucio;

import java.util.ArrayList;
import java.util.List;


public class Agencia {
    private String nombre;
     private List <Nave> listaNave;

    public Agencia(String nombre) {
        this.nombre = nombre;
        this.listaNave = new ArrayList<>();
    }
    
    
    public void agregarNave(Nave nave)
    {
       if(nave == null)
       {
         throw  new NullPointerException("Me pasaste un null en lugar de una nave");
       }
       if(listaNave.contains(nave)){
           throw  new NaveRepetidadExepcion();
       }
       listaNave.add(nave);
      
    } 
    
    
    public void mostrarNaves(){
        if(listaNave.isEmpty()){
            System.out.println("La lista de naves esta vacia....");
        }
        for(Nave p: listaNave)
        {
            System.out.println(p);
        }
    }
     
     public void iniciarExploracion(){
        for(Nave p: listaNave){
            if(p instanceof Explorable explorable )
            {
              explorable.explorar();
            }
            else
            {
               System.out.println(" los cruceros estelares no pueden iniciar una mision ya que transportan pasajeros");
            }
        }
    }
    
    
}
