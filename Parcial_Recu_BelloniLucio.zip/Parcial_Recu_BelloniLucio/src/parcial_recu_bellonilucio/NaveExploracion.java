
package parcial_recu_bellonilucio;


public class NaveExploracion extends Nave implements Explorable{
    private Mision tipoMision;

    public NaveExploracion(String nombre, int capacidad, int anioDeLanzamiento, Mision tipoMision) {
        super(nombre, capacidad, anioDeLanzamiento);
        this.tipoMision = tipoMision;
    }

    @Override
    public void explorar() {
        System.out.println("Nava Explorando esta Iniciando Exploracion .... ");
    }

    @Override
    public String toString() {
        return super.toString() + " tipoMision: " + tipoMision;
    }
    
    
    
    
}
