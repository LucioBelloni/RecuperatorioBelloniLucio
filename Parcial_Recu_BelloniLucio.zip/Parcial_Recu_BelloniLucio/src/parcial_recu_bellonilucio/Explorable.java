
package parcial_recu_bellonilucio;


public interface Explorable {
    
    void explorar();
}
