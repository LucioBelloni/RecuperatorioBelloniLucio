
package parcial_recu_bellonilucio;


public class Carguero extends Nave implements Explorable { 
    
    private int cantidadCarga;
    private static final int MIN_CANTIDAD = 100;
    private static final int MAX_CANTIDAD = 500;
    
    public Carguero(String nombre, int capacidad, int anioDeLanzamiento, int cantidadCarga) {
        super(nombre, capacidad, anioDeLanzamiento);
        validarCantidadCarga(cantidadCarga);
        this.cantidadCarga = cantidadCarga;
    }

    @Override
    public void explorar() {
        System.out.println("Iniciando exploracion de Carguero");
    }

    @Override
    public String toString() {
        return  super.toString() + " cantidadCarga: " + cantidadCarga;
    }
    
    private boolean validarCantidadCarga(int cantidadCarga){
        if(cantidadCarga >= MIN_CANTIDAD && cantidadCarga <= MAX_CANTIDAD){
            return true;
        }
        throw new IllegalArgumentException("me pasaste un numero mas grande que 500 y mas chico que 100");
    }
    
    
}
