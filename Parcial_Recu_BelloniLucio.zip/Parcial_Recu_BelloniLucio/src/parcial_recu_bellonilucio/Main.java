
package parcial_recu_bellonilucio;


public class Main {

   public static void main(String[] args) {
    
        Agencia nave = new Agencia("Nave de berazategui");
        
        try{
           
            nave.agregarNave(new CruceroEstelar("Arcadia", 100, 2010, 300));
            nave.agregarNave(new CruceroEstelar("Battlestar Galactica", 200, 1910, 20));
            nave.agregarNave(new NaveExploracion("Halcon Milenario",20,1999,Mision.CONTACTO));
            nave.agregarNave(new Carguero("Serenity",20,2030,300));
            
        } 
        catch (RuntimeException e) {
            System.out.println(e.getMessage());    
        }
        
        nave.mostrarNaves();
        nave.iniciarExploracion();
        
        
    }
    
}
