
package parcial_recu_bellonilucio;


public class CruceroEstelar extends Nave{
    
    private int cantidadDePasajeros;
    
    
    public CruceroEstelar(String nombre, int capacidad, int anioDeLanzamiento,int cantidadDePasajeros) {
        super(nombre, capacidad, anioDeLanzamiento);
        validarCantidadPasajeros(cantidadDePasajeros);
        this.cantidadDePasajeros = cantidadDePasajeros;
    }

    @Override
    public String toString() {
        return  super.toString()  + " cantidadDePasajeros: " + cantidadDePasajeros;
    }
    
    private boolean validarCantidadPasajeros(int cantidadDePasajeros){
        if(cantidadDePasajeros >= 1){
            return true;
        }
        throw new IllegalArgumentException("me pasaste una cantidad negativa");
    }
    
}
