
package parcial_recu_bellonilucio;


public enum Mision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO
}
